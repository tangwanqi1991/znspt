export default {
    isAuthenticated: state => state.isAuthenticated,
    user: state => state.user,
}