<template>
    <div>
        123
    </div>
</template>
<script>
    export default {
        name: 'listTypeData',
        data () {
            return {
                
            }
        }
    }
</script>
<style scoped> 
</style>
