<template>
  <div class="nofind">
      <img src="../assets/404.gif" alt="">
  </div>
</template>

<script>
// @ is an alias to /src
export default {
  name: 'Nofind',
}
</script>
<style scoped>
.nofind {
  width: 100%;
  height: 100%;
  overflow: hidden;
}
.nofind img {
  width: 100%;
  height: 100%;
}
</style>
